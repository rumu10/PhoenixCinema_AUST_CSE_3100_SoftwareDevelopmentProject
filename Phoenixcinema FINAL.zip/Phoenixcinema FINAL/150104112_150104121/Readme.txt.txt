PhoenixCinema. It's a movie theatre website.Where you can find out ongoing,coming up movies as well as 
their information such as release date,IMDB rating,casts etc.You can also book ticket of your desire movie.

to run -> localhost/PhoenixCinema/PhoenixCinema.php

1. After entering the above address, you'll jump into our homepage. Then you can navigate through the pages from the menu bars and links.

2. For checking the informations of now showing,next arrival and archieve  movies, go to the movies dropdown menu from the menu bar.
Then mouse over the movie poster for details.

3. To know times of your desired movies you can go to the showtime menu.And to know price of ticket you can check Ticket Price from menu bar.

4. There is an option for a user to signup or login when you'll click the "Buy Ticket" button. Logging in to his/her profile, 
he/she can order the desired movie ticket. 

	     
