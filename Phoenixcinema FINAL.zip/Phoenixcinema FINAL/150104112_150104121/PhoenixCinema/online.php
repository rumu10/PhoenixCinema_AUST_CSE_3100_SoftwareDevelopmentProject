<html>
	<head>
		<title>Online for C2</title>
	</head>
	<body>
		Create a table containing names of some cars.
		Then query list of those cars and populate the 
		following dropdown list.
		<br>
		Car list: 
		<select>
		  <option value="volvo">Volvo</option>
		  <option value="saab">Saab</option>
		  <option value="mercedes">Mercedes</option>
		  <option value="audi">Audi</option>
		</select> 
	</body>
</html>
